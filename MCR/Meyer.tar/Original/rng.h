#ifndef RNG_H
#define RNG_H

#include <stdlib.h>

void randombytes(void *x, size_t l);

#endif
